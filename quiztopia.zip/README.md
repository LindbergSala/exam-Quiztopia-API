# Quiztopia API (Serverless)

Setup för Serverless-backend (API Gateway + Lambda + DynamoDB).
Byggs stegvis: auth (JWT), quiz-CRUD, frågor med lat/lon, leaderboard.

Scripts:
- `npm run build` – paketera (Steg 2 sätter upp serverless.yml)
- `npm run deploy` – deploy till AWS (senare steg)
- `npm run remove` – ta bort stack
- `npm run test` – Node test runner (enkla tester)